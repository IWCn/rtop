<?php
$load=$_REQUEST['edit'];
if(isset($_REQUEST['edit']))
{
$getdata=$db->get_row('testimonial',array('id'=>$load));

}

if(isset($_POST['update']))
{
	 $name=$_POST['name'];
	 $job=$_POST['job'];
	 $work_at=$_POST['work_at'];
	 $content=$_POST['content'];
	 $ip_address=$_SERVER['REMOTE_ADDR'];
	 
	$image=$_FILES['image'];
	 $handle= new upload($_FILES['image']);
	 $path=SERVER_ROOT.'/uploads/testimonial/'.$getdata['id'].'/';
	  
	 if(!is_dir($path))
	 {
	     if(!file_exists($path))
	     {
	         mkdir($path);
	     }
	 }
	 
	 
	 
	 
	 if($fv->emptyfields(array('name'=>$name),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Name</b>
                      </div>';
	 }
	 elseif($fv->emptyfields(array('job'=>$job),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Job</b>
                      </div>';
	 }
	 elseif($fv->emptyfields(array('work_at'=>$work_at),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Work At</b>
                      </div>';
	 }
	 elseif($fv->emptyfields(array('content'=>$content),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Content</b>
                      </div>';
	 }
	 elseif(($image['name']) != '')
	 {
	     if(file_exists(SERVER_ROOT.'/uploads/testimonial/'.$load.'/'.$getdata['image']) && (($getdata['image'])!=''))
	     {
	         unlink(SERVER_ROOT.'/uploads/testimonial/'.$load.'/'.$getdata['image']);
	 
	     }
	     $newfilename = $handle->file_new_name_body=$load;
	     $ext = $handle->image_src_type;
	     $filename = $newfilename.'.'.$ext;
	 
	     if ($handle->image_src_type == 'jpg' || $handle->image_src_type == 'JPEG' || $handle->image_src_type == 'jpeg' || $handle->image_src_type == 'png' || $handle->image_src_type == 'JPG')
	     {
	          
	         if ($handle->uploaded)
	         {
	              
	             $handle->Process($path);
	             if ($handle->processed)
	             {
	                  
	                 $update=$db->update('testimonial',array('image'=>$filename,'name'=>$name,'job'=>$job,'work_at'=>$work_at,'content'=>$content,'ip_address'=>$ip_address),array('id'=>$load));
	                 $update=1;
	                  
	 
	             }
	              
	         }
	     }
	      
	 }
	 
	 
	 else
	 {
	     $update=$db->update('testimonial',array('name'=>$name,'job'=>$job,'work_at'=>$work_at,'content'=>$content,'ip_address'=>$ip_address),array('id'=>$load));
	 
	 }
	 
	 if($update)
	 {
	      
	     $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Form Update Successfully</b>
                      </div>';
	 }
	 








} 
	 
	 
	 
	 
	 
	 
	 
	 
	 ?>