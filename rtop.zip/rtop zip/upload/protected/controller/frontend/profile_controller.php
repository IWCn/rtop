<?php 

if(isset($_POST['update']))
{
     $role=$_POST['role'];
	 $name=$_POST['name'];
	 $email=$_POST['email'];
     $phone_no=$_POST['phone_no'];
	 $ip_address=$_SERVER['REMOTE_ADDR'];

  


if($role=='')
	{
		$display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Select Role</b> 
                      </div>';
	}
	
	
	elseif ($fv->emptyfields(array('name'=>$name),NULL))
	{
		$display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Name</b> 
                      </div>';
	}
	
   
       elseif($fv->emptyfields(array('phone_no'=>$phone_no),NULL))
       {
           $display_msg='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>Please Enter Phone no.
		</div>';
       }
   else
	{
	
	$update=$db->update('user',array('name'=>$name,
			'phone_no'=>$phone_no,'ip_address'=>$ip_address,'role'=>$role),array('email'=>$_SESSION['email']));
	
	}

    if($update)
    {
         
        $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Form Update Successfully</b>
                      </div>';
    }
     

}

?>