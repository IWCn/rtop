<?php
$getdata=$db->get_row('social',array('id'=>1));
if(isset($_POST['update']))
{
     $facebook=$_POST['facebook'];
     $twitter=$_POST['twitter'];
    $google=$_POST['google'];
   
    $linkedin=$_POST['linkedin'];
    $pinterest=$_POST['pinterest'];
   
    $ip_address=$_SERVER['REMOTE_ADDR'];


    if($fv->emptyfields(array('facebook'=>$facebook),NULL))
    {
        $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Facebook URL</b>
                      </div>';
    }
    elseif($fv->emptyfields(array('twitter'=>$twitter),NULL))
    {
        $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Twitter URL</b>
                      </div>';
    }
    elseif($fv->emptyfields(array('pinterest'=>$pinterest),NULL))
    {
        $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Pinterest URL</b>
                      </div>';
    }
   
    
    elseif($fv->emptyfields(array('linkedin'=>$linkedin),NULL))
    {
        $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Thursday Opening Time</b>
                      </div>';
    }
    elseif($fv->emptyfields(array('google'=>$google),NULL))
    {
        $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Google URL</b>
                      </div>';
    }
   
    else
    {
     //  $insert=$db->insert('social',array('facebook'=>$facebook,'tumblr'=>$tumblr,'twitter'=>$twitter,'google'=>$goolge,'stumbleupon'=>$stumbleupon,'dribbble'=>$dribbble,'digg'=>$digg,'flickr'=>$flickr,'instagram'=>$instagram,'linkedin'=>$linkedin,'pinterest'=>$pinterest,'vimeo'=>$vimeo,'youtube'=>$youtube));
       
        $update=$db->update('social',array('facebook'=>$facebook,'twitter'=>$twitter,'google'=>$google,'linkedin'=>$linkedin,'pinterest'=>$pinterest),array('id'=>1));
    }
    if($update)
    {

        $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Form Updated Successfully</b>
                      </div>';
    }


}
?>