<?php
$load=$_REQUEST['orderid'];
$select=$db->get_row('order_final',array('id'=>$load));
$get_client=$db->get_row('user',array('id'=>$select['client_id']));
$get_setting=$db->get_row('setting',array('id'=>1));
$select1=$db->get_row('order_final',array('id'=>$load));
$product=$select1[products];
$product_final=unserialize($product);


?>