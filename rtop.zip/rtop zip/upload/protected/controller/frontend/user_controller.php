<?php

$select=$db->get_all('user');
if(isset($_POST['view']))
{
    $role=$_POST['role'];
    if($role=='')
    {
        $select=$db->get_all('user');
    }
    else{
    $select=$db->get_all('user',array('role'=>$role));
    }
  

}

if(isset($_REQUEST['del']))
{
   
{
    $display_msg='<form method="POST" action="">
<div class="alert alert-success" >
Are you sure ? You want to delete this .
<input type="hidden" name="del" value="'.$_REQUEST['del'].'" >
<button name="yes" type="submit" class="btn btn-success btn-xs"  aria-hidden="true"><i class="icon-ok-sign"></i></button>
<button name="no" type="submit" class="btn btn-danger btn-xs"  aria-hidden="true"><i class="icon-remove"></i></button>
</div>
</form>';
}
if(isset($_POST['yes']))
{
    $delete=$db->delete("user",array('id'=>$_REQUEST['del']));
    

    if($delete)
    {
        $session->redirect('user',frontend);
    }
}
elseif(isset($_POST['no']))
{
    $session->redirect('user',frontend);
}

}




if(isset($_POST['submit']))
{
	 $role=$_POST['role'];
	 $name=$_POST['name'];
	 $email=$_POST['email'];
	 $pass=$_POST['pass'];
     $phone_no=$_POST['phone_no'];
    $created_date=date('y-m-d h:i:s');
	 $ip_address=$_SERVER['REMOTE_ADDR'];
	
	if($role=='')
	{
		$display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Select Role</b> 
                      </div>';
	}
	
	
	elseif ($fv->emptyfields(array('name'=>$name),NULL))
	{
		$display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Name</b> 
                      </div>';
	}
	
    else if(($fv->emptyfields(array('email'=>$email),NULL)))
       {
          $display_msg='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>Please Enter Email!!
		</div>';
       }
       elseif(!$fv->check_email($email))
       {
          $display_msg='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>Wrong Email Format!!
		</div>';
       }
       elseif($db->exists('user',array('email'=>$email)))
       {
          $display_msg= '<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">�</button> Email Already Exist!!
        </div>';
       }
       elseif($fv->emptyfields(array('password'=>$pass),NULL))
       {
           $display_msg='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>Please Enter Password!!
		</div>';
       }
       elseif($fv->emptyfields(array('phone_no'=>$phone_no),NULL))
       {
           $display_msg='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>Please Enter Password!!
		</div>';
       }
	else 
	{

	    $encrypt_password = $password->hashBcrypt( $pass);
	    $insert=$db->insert('user',array('name'=>$name,'phone_no'=>$phone_no,'role'=>$role,'email'=>$email,'password'=>$encrypt_password,'created_date'=>$created_date,'ip_address'=>$ip_address));
       
	    if($insert)
	    {
	       $display_msg='<div class="alert alert-success">
		   <button class="close" data-dismiss="alert" type="button">X</button>Form Successfully Submitted
           </div>';
	    }
	
	}	

				
    }
    ?>



