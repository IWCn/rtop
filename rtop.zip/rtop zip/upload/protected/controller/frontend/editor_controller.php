<?php
$get_note=$db->get_row('editor',array('id'=>1));
if(isset($_POST['submit']))
{
    $notes=$_POST['notes'];
    
    $ip_address=$_SERVER['REMOTE_ADDR'];
    
if($fv->emptyfields(array('notes'=>$notes),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Something....</b>
                      </div>';
	 }
	 else 
	 {
	     $update=$db->update('editor',array('notes'=>htmlentities($notes),'ip_address'=>$ip_address),array('id'=>1));
	 }
	 if($update)
	 {
	     $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Update Successfully</b>
                      </div>';
	 }
}
?>