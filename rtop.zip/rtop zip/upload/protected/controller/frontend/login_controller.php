<?php 
if ($session->Check())
{
$session->redirect('home',frontend);
}
$getdata=$db->get_row('setting',array('id'=>1));
if(isset($_POST['login']))
{
$email=$_POST['email'];
$pass=$_POST['password'];
	
if($fv->emptyfields(array('email'=>$email),NULL))
	{
		$message='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                      <b>Please Enter E-Mail</b> 
                      </div>';
	}
	elseif(!$fv->check_email($email))
	{
	    $message='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>
	        <b>Wrong E-Mail Format</b>
		</div>';
	}

elseif($pass=='')
{
$message='<div class="alert alert-danger">
    <button class="close" data-dismiss="alert" type="button">X</button>
<b>Please Enter Password</b>
</div>';
}
elseif (!$db->exists('user',array('email'=>$email)))
{
    $message='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>
        <b>Invalid Email/Does not Exist</b>
		</div>';
}
    else 
       {
           $data=$db->get_row('user',array('email'=>$email));
        
           if(is_array($data))
           {
              
          $check_pass = $password->verify($pass, $data['password']);
               
               if(!$check_pass)
               {
                 
                   $message='<div class="alert alert-danger">
                    <button class="close" data-dismiss="alert" type="button">X</button>
                       <b>Incorrect Password</b>
                    </div>';
               }
               else
               {
                   $session->Open();
                   if(isset($_SESSION))
                   {
                       $_SESSION['email'] = $email;
                       $_SESSION['id']= $data['id'];
                       $_SESSION['name']= $data['name'];
                       $_SESSION['role']= $data['role'];
                       $_SESSION['phone_no']= $data['phone_no'];
                      $session->redirect('home',user);
                     
                   }
               }
           }
           else
           {
               $message='<div class="alert alert-danger">
                <button class="close" data-dismiss="alert" type="button">X</button>
                   <b>Wrong Email or Password</b>
                </div>';
               
           }
           
       }
}
?>