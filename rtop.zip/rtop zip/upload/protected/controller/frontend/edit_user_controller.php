<?php

$load=$_REQUEST['edit'];
if(isset($_REQUEST['edit']))
{
    $getdata=$db->get_row('user',array('id'=>$load));

}
if(isset($_POST['update']))
{
    $role=$_POST['role'];
	 $name=$_POST['name'];
	 $email=$_POST['email'];
	 $pass=$_POST['pass'];
     $phone_no=$_POST['phone_no'];
	 $ip_address=$_SERVER['REMOTE_ADDR'];

  


if($role=='')
	{
		$display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Select Role</b> 
                      </div>';
	}
	
	
	elseif ($fv->emptyfields(array('name'=>$name),NULL))
	{
		$display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Name</b> 
                      </div>';
	}
	
   
       elseif($fv->emptyfields(array('phone_no'=>$phone_no),NULL))
       {
           $display_msg='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>Please Enter Password!!
		</div>';
       }
    elseif ($pass == '')
	{
		$update=$db->update('user',array('name'=>$name,
				'phone_no'=>$phone_no,'role'=>$role,'ip_address'=>$ip_address),array('id'=>$load));
	}
else
	{
	$encrypt_pass=$password->hashBcrypt($pass);
	$update=$db->update('user',array('name'=>$name,'password'=>$encrypt_pass,
			'phone_no'=>$phone_no,'ip_address'=>$ip_address,'role'=>$role),array('id'=>$load));
	}

    if($update)
    {
         
        $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Form Update Successfully</b>
                      </div>';
    }
     

}


?>
	 	 