<?php
$getdata=$db->get_row('banner',array('id'=>1));
if(isset($_POST['update']))
{
    $banner_text=$_POST['banner_text'];
    $banner_heading=$_POST['banner_heading'];
    $banner=$_FILES['banner'];
    $ip_address=$_SERVER['REMOTE_ADDR'];
   // $created_date=date('y-m-d h:i:s');
    $handle= new upload($_FILES['banner']);
  
    $path=SERVER_ROOT.'/uploads/banner/';
    if(!is_dir($path))
    {
        if(!file_exists($path))
        {
            mkdir($path);
        }
    }
    
    
    if($fv->emptyfields(array('banner_text'=>$banner_text),NULL))
    {
        $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Banner Text</b>
                      </div>';
    }
    
    elseif($fv->emptyfields(array('banner_heading'=>$banner_heading),NULL))
    {
        $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Banner Heading</b>
                      </div>';
    }
    
   
    
   
   
    elseif(($banner['name']) != '')
    {
        if(file_exists(SERVER_ROOT.'/uploads/banner/'.$getdata['banner']) && (($getdata['banner'])!=''))
        {
            unlink(SERVER_ROOT.'/uploads/banner/'.$getdata['banner']);
    
        }
    
        $newfilename = $handle->file_new_name_body='banner';
        $ext = $handle->image_src_type;
        $filename = $newfilename.'.'.$ext;
    
    
        if ($handle->image_src_type == 'jpg' || $handle->image_src_type == 'jpeg' || $handle->image_src_type == 'JPEG' || $handle->image_src_type == 'png' || $handle->image_src_type == 'JPG')
        {
    
    
            if ($handle->uploaded)
            {
                echo "dfgdhdfh";
                $handle->Process($path);
                if ($handle->processed)
                {
                   // $insert=$db->insert('banner',array('banner'=>$filename,'banner_text'=>$banner_text,'banner_heading'=>$banner_heading,'ip_address'=>$ip_address,'created_date'=>$created_date));
                    
                    $update=$db->update('banner',array('banner'=>$filename,'banner_text'=>$banner_text,'banner_heading'=>$banner_heading,'ip_address'=>$ip_address),array('id'=>1));
    
                }
            }
        }
    
    }
    
    else
    {
      // $insert=$db->insert('banner',array('banner_text'=>$banner_text,'banner_heading'=>$banner_heading,'ip_address'=>$ip_address,'created_date'=>$created_date));
                     
      $update=$db->update('banner',array('banner_text'=>$banner_text,'banner_heading'=>$banner_heading,'ip_address'=>$ip_address),array('id'=>1));
    }
    if($update)
    {
    
        $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Form Updated Successfully</b>
                      </div>';
    }
    
    
}
?>