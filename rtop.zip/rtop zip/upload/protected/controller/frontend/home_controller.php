<?php

$get_category=$db->get_count('category');
$get_food=$db->get_count('food');
$get_room=$db->get_count('room');
$get_table=$db->get_count('table');
$get_client=$db->get_count('user',array('role'=>Client));
$get_invoice=$db->get_count('order_final');
$get_event=$db->get_count('event');
$get_testimonial=$db->get_count('testimonial');
$db->limit="0,10";
 $db->order_by='`id` DESC';


$select=$db->get_all('order_final');

?>