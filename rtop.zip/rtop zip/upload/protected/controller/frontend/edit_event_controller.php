<?php
$load=$_REQUEST['edit'];
if(isset($_REQUEST['edit']))
{
$getdata=$db->get_row('event',array('id'=>$load));

}

if(isset($_POST['update']))
{
	  $event_name=$_POST['event_name'];
	  $post_by=$_POST['post_by'];
	 $event_loc=$_POST['event_loc'];
	 $event_des=$_POST['event_des'];
	 $date=$_POST['date'];
	 $time=$_POST['time'];
	 $ip_address=$_SERVER['REMOTE_ADDR'];
	 
	$image=$_FILES['image'];
	 $handle= new upload($_FILES['image']);
	 $path=SERVER_ROOT.'/uploads/event/'.$getdata['id'].'/';
	  
	 if(!is_dir($path))
	 {
	     if(!file_exists($path))
	     {
	         mkdir($path);
	     }
	 }
	 
	 
	 
	 
	 if($fv->emptyfields(array('event_name'=>$event_name),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Event Name</b>
                      </div>';
	 }
	 else if($fv->emptyfields(array('post_by'=>$post_by),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Post By</b>
                      </div>';
	 }
	 elseif($fv->emptyfields(array('event_loc'=>$event_loc),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Event Location</b>
                      </div>';
	 }
	 elseif($fv->emptyfields(array('event_des'=>$event_des),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Event Description</b>
                      </div>';
	 }
	 elseif($fv->emptyfields(array('date'=>$date),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Date</b>
                      </div>';
	 }
	 elseif(($image['name']) != '')
	 {
	     if(file_exists(SERVER_ROOT.'/uploads/event/'.$load.'/'.$getdata['image']) && (($getdata['image'])!=''))
	     {
	         unlink(SERVER_ROOT.'/uploads/event/'.$load.'/'.$getdata['image']);
	 
	     }
	     $newfilename = $handle->file_new_name_body=$load;
	     $ext = $handle->image_src_type;
	     $filename = $newfilename.'.'.$ext;
	 
	     if ($handle->image_src_type == 'jpg' || $handle->image_src_type == 'JPEG' || $handle->image_src_type == 'jpeg' || $handle->image_src_type == 'png' || $handle->image_src_type == 'JPG')
	     {
	          
	         if ($handle->uploaded)
	         {
	              
	             $handle->Process($path);
	             if ($handle->processed)
	             {
	                  
	                 $update=$db->update('event',array('post_by'=>$post_by,'image'=>$filename,'event_name'=>$event_name,'event_loc'=>$event_loc,'event_des'=>$event_des,'date'=>$date,'time'=>$time,'ip_address'=>$ip_address),array('id'=>$load));
	                 $update=1;
	                  
	 
	             }
	              
	         }
	     }
	      
	 }
	 
	 
	 else
	 {
	     $update=$db->update('event',array('post_by'=>$post_by,'event_name'=>$event_name,'event_loc'=>$event_loc,'event_des'=>$event_des,'date'=>$date,'time'=>$time,'ip_address'=>$ip_address),array('id'=>$load));
	 
	 }
	 
	 if($update)
	 {
	      
	     $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Form Update Successfully</b>
                      </div>';
	 }
	 








} 
	 
	 
	 
	 
	 
	 
	 
	 
	 ?>