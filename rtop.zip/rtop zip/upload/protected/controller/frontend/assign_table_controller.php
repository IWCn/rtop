<?php
$get=$db->get_all('table');
if(isset($_REQUEST['assign']))
{
    $select=$db->get_row('booking',array('id'=>$_REQUEST['assign']));

}

if(isset($_POST['submit']))
{
   $id=$_POST['table'];
   $select1=$db->get_row('table',array('id'=>$id));
   
   $update=$db->update('booking',array('staff_verified'=>1,'table'=>$select1['table_no'],'room'=>$select1['room']),array('id'=>$_REQUEST['assign']));

   if($update)
   {
       $session->redirect('completed_bookings',frontend);
   }
}
?>