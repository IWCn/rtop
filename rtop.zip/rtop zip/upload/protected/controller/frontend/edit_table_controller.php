<?php
$load=$_REQUEST['edit'];
if(isset($_REQUEST['edit']))
{
$getdata=$db->get_row('table',array('id'=>$load));

}
if(isset($_POST['update']))
{
    $table_no=$_POST['table_no'];
    $available_place=$_POST['available_place'];
    $table_pos=$_POST['table_pos'];
    $room=$_POST['room'];
    $new_room=$_POST['room'];
  
    $created_date=date('y-m-d h:i:s');
    $ip_address=$_SERVER['REMOTE_ADDR'];
    
 
	 
	 $image=$_FILES['image'];
	
	 $handle= new upload($_FILES['image']);
	 $path=SERVER_ROOT.'/uploads/room/'.$getdata['id'].'/';
	  
	 if(!is_dir($path))
	 {
	     if(!file_exists($path))
	     {
	         mkdir($path);
	     }
	 }
	 
	 
   if ($fv->emptyfields(array('table_no'=>$table_no),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Table No</b>
                      </div>';
	 }
	 elseif ($fv->emptyfields(array('available_place'=>$available_place),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                      <b>Enter No of Places</b>
                      </div>';
	 }
	 elseif ($fv->emptyfields(array('table_pos'=>$table_pos),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                      <b>Enter Postion of Table</b>
                      </div>';
	 }
	 
	else if($room=='')
	{
		$display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Select Room </b> 
                      </div>';
	}
	
	 elseif(($image['name']) != '')
	 {
	     if(file_exists(SERVER_ROOT.'/uploads/room/'.$load.'/'.$getdata['image']) && (($getdata['image'])!=''))
	     {
         unlink(SERVER_ROOT.'/uploads/room/'.$load.'/'.$getdata['image']);
        
	     }
	     $newfilename = $handle->file_new_name_body=$load;
	     $ext = $handle->image_src_type;
	     $filename = $newfilename.'.'.$ext;
	     
	     if ($handle->image_src_type == 'jpg' || $handle->image_src_type == 'JPEG' || $handle->image_src_type == 'jpeg' || $handle->image_src_type == 'png' || $handle->image_src_type == 'JPG')
	     {
	          
	         if ($handle->uploaded)
	         {
	              
	             $handle->Process($path);
	             if ($handle->processed)
	             {
	                
	               $update=$db->update('table',array('image'=>$filename,'new_room'=>$room,'room'=>$room,'available_place'=>$available_place,'table_pos'=>$table_pos,'table_no'=>$table_no,'ip_address'=>$ip_address),array('id'=>$load));
                   $update=1;   
	                 
	                 
	             }
	    
	         }
	     }
	      
	 }
	 
	 else
	  {
	      
	     
	         $update=$db->update('table',array('new_room'=>$room,'room'=>$room,'available_place'=>$available_place,'table_pos'=>$table_pos,'table_no'=>$table_no,'ip_address'=>$ip_address),array('id'=>$load));
	      	  

	  }

	  if($update)
	  {
	  
	      $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Form Update Successfully</b>
                      </div>';
	  }  
	  
	 
	 }
	
	 
	 ?>
	 	 
