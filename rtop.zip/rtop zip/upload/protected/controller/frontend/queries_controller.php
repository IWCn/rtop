<?php

$db->order_by='`id` DESC';
$select=$db->get_all('contact');
?>