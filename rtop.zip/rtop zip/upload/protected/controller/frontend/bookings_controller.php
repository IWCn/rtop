<?php
$select=$db->get_all('booking',array('staff_verified'=>0));


if(isset($_REQUEST['del']))
{
    {
        $display_msg='<form method="POST" action="">
<div class="alert alert-success" >
Are you sure ? You want to delete this .
<input type="hidden" name="del" value="'.$_REQUEST['del'].'" >
<button name="yes" type="submit" class="btn btn-success btn-xs"  aria-hidden="true"><i class="icon-ok-sign"></i></button>
<button name="no" type="submit" class="btn btn-danger btn-xs"  aria-hidden="true"><i class="icon-remove"></i></button>
</div>
</form>';
    }
    if(isset($_POST['yes']))
    {
        $delete=$db->delete("booking",array('id'=>$_REQUEST['del']));
         

        if($delete)
        {
           
            $session->redirect('bookings',frontend);
        }
         
    }
    elseif(isset($_POST['no']))
    {
         
        $session->redirect('bookings',frontend);
    }

}
?>