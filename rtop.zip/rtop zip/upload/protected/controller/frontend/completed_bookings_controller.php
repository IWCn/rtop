<?php

$select=$db->get_all('booking',array('staff_verified'=>1));
if(isset($_REQUEST['guest']))
{
  
    $update=$db->update('booking',array('guests'=>1),array('id'=>$_REQUEST['guest']));
    if($update)
    {
        $session->redirect('completed_bookings',frontend);
    }

}
if(isset($_REQUEST['del']))
{
    {
        $display_msg='<form method="POST" action="">
<div class="alert alert-success" >
Are you sure ? You want to delete this .
<input type="hidden" name="del" value="'.$_REQUEST['del'].'" >
<button name="yes" type="submit" class="btn btn-success btn-xs"  aria-hidden="true"><i class="icon-ok-sign"></i></button>
<button name="no" type="submit" class="btn btn-danger btn-xs"  aria-hidden="true"><i class="icon-remove"></i></button>
</div>
</form>';
    }
    if(isset($_POST['yes']))
    {
        $delete=$db->delete("booking",array('id'=>$_REQUEST['del']));
         

        if($delete)
        {
             
            $session->redirect('completed_bookings',frontend);
        }
         
    }
    elseif(isset($_POST['no']))
    {
         
        $session->redirect('completed_bookings',frontend);
    }

}

?>

