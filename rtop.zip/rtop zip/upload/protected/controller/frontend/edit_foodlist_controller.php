<?php
$get_setting=$db->get_row('setting',array('id'=>1));
$load=$_REQUEST['edit'];
if(isset($_REQUEST['edit']))
{
$getdata=$db->get_row('food',array('id'=>$load));

}
if(isset($_POST['update']))
{
	  $category=$_POST['category'];
	 $food_category=$_POST['category'];
	 $name=$_POST['name'];
	 $detail=$_POST['detail'];
	 $price=$_POST['price'];
	 $tags=$_POST['tags'];
	
	 $created_date=date('y-m-d h:i:s');
	 $ip_address=$_SERVER['REMOTE_ADDR'];
	 
	 $image=$_FILES['image'];
	
	 $handle= new upload($_FILES['image']);
	 $path=SERVER_ROOT.'/uploads/food/'.$getdata['id'].'/';
	  
	 if(!is_dir($path))
	 {
	     if(!file_exists($path))
	     {
	         mkdir($path);
	     }
	 }
	 
	 
	 if($category=='')
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Select Food Category </b>
                      </div>';
	 }
	 elseif ($fv->emptyfields(array('name'=>$name),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Please Enter Name</b>
                      </div>';
	 }
	 elseif ($fv->emptyfields(array('detail'=>$detail),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                      <b>Enter Details</b>
                      </div>';
	 }
	 elseif ($fv->emptyfields(array('price'=>$price),NULL))
	 {
	     $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                      <b>Enter Price</b>
                      </div>';
	 }
	 elseif(($image['name']) != '')
	 {
	     if(file_exists(SERVER_ROOT.'/uploads/food/'.$load.'/'.$getdata['image']) && (($getdata['image'])!=''))
	     {
         unlink(SERVER_ROOT.'/uploads/food/'.$load.'/'.$getdata['image']);
        
	     }
	     $newfilename = $handle->file_new_name_body=$load;
	     $ext = $handle->image_src_type;
	     $filename = $newfilename.'.'.$ext;
	     
	     if ($handle->image_src_type == 'jpg' || $handle->image_src_type == 'JPEG' || $handle->image_src_type == 'jpeg' || $handle->image_src_type == 'png' || $handle->image_src_type == 'JPG')
	     {
	        
	         if ($handle->uploaded)
	         {
	   
	             $handle->Process($path);
	             if ($handle->processed)
	             {
	                
	               $update=$db->update('food',array('tags'=>$tags,'image'=>$filename,'food_category'=>$category,'category'=>$category,'name'=>$name,'detail'=>$detail,'price'=>$price,'ip_address'=>$ip_address),array('id'=>$load));
                   $update=1;   
	                    
	                 
	             }
	    
	         }
	     }
	      
	 }
	 
	 else
	  {
	         $update=$db->update('food',array('tags'=>$tags,'food_category'=>$category,'category'=>$category,'name'=>$name,'detail'=>$detail,'price'=>$price,'ip_address'=>$ip_address),array('id'=>$load));
	       
	  }

	  if($update)
	  {
	  
	      $display_msg='<div class="alert alert-success">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     <b>Form Update Successfully</b>
                      </div>';
	  }  
	  
	 
	 }
	
	 
	 ?>
	 	 