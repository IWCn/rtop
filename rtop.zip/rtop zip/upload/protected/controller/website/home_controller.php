<?php
$get_testimonial=$db->get_all('testimonial');
$event=$db->get_all('event');
$category=$db->get_all('category');
$about=$db->get_row('editor',array('id'=>1));
$gallery=$db->get_all('image_name');
$social=$db->get_row('social',array('id'=>1));
 $day=date(D);
 $table=$db->get_all('table');
 
 
 
 if(isset($_POST['sendmessage']))
 {
    $contact_msg=$_POST['contact_msg'];
     $contact_email=$_POST['contact_email'];
     $created_date=date('y-m-d h:i:s');
     $ip_address=$_SERVER['REMOTE_ADDR'];
     
     if ($fv->emptyfields(array('contact_email'=>$contact_email),NULL))
     {
        $message='<a href="#">Please Enter Contact E-Mail.........X</a><br><br>';
                      
        
     }
     elseif (!$fv->check_email($contact_email))
     {
          $message='<a href="#" class="">Wrong E-Mail Format.........X</a><br><br>';
     }
     
     elseif ($fv->emptyfields(array('contact_msg'=>$contact_msg),NULL))
     {
          $message='<a href="#" class="">Please Enter Message.........X</a><br><br>';
                     
     }
     else
     {
         $insert=$db->insert('contact',array('contact_email'=>$contact_email,'contact_msg'=>$contact_msg,'created_date'=>$created_date,'ip_address'=>$ip_address));
     }
     if($insert)
     {
     
       
         $message='<a href="#" class="">Form Submitted Successfully.........X</a><br><br>';
        
                 
     }
 }
 
 
 
 if(isset($_POST['submit']))
 {
    
     $name=$_POST['name'];
     $date=$_POST['date'];
   $date1= explode('-', $_POST['date']);
 
     $time=$_POST['time'];
     $time1=explode(':', $_POST['time']);
     $person=$_POST['person'];
     $email=$_POST['email'];
     $phone_no=$_POST['phone_no'];
     $created_date=date('y-m-d h:i:s');
     $ip_address=$_SERVER['REMOTE_ADDR'];
     
     
     if ($fv->emptyfields(array('name'=>$name),NULL))
     {
         $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter Name
                      </div>';
     }
     elseif($person=='')
     {
         $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Select No. of Persons
                      </div>';
     }
 
	elseif ($fv->emptyfields(array('date'=>$date),NULL))
	{
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter Date
                      </div>';
	}
	elseif (!preg_match('/-/',$date))
	{
	   
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                    Please Enter Correct Date
                      </div>';
	}
	elseif($date1[0]>12)
	{
	     
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter Correct Month
                      </div>';
	}
	
	else if($date1[1]>31)
	{
	     
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter Correct Date
                      </div>';
	}
	else if($date1[2]<15)
	{
	
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter Correct Year
                      </div>';
	}
	

	elseif ($fv->emptyfields(array('time'=>$time),NULL))
	{
	    
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter Time
                      </div>';
	}
	elseif (!preg_match('/:/',$time))
	{
	
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                   Wrong Format of Time
                      </div>';
	}
	else if($time1[0]>23)
	{
	     
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter Correct Time
                      </div>';
	}
	else if($time1[1]>59)
	{
	     
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter Correct Time
                      </div>';
	}
	elseif ($fv->emptyfields(array('email'=>$email),NULL))
	{
	    $display_msg='<div class="alert alert-danger">
                      <button class="close" data-dismiss="alert" type="button">X</button>
                     Please Enter E-Mail
                      </div>';
	}
  elseif(!$fv->check_email($email))
       {
          $display_msg='<div class="alert alert-danger ">
		<button class="close" data-dismiss="alert" type="button">X</button>Wrong Email Format!!
		</div>';
       }

       
      
                   
              else   
               {  
        $insert=$db->insert('booking',array('time'=>$time,'date'=>$date,'name'=>$name,'person'=>$person,'phone_no'=>$phone_no,'email'=>$email,'created_date'=>$created_date,'ip_address'=>$ip_address));
       
               }  
                
           if($insert)
           {
           $display_msg='<div class="alert alert-success ">
		<button class="close" data-dismiss="alert" type="button">X</button>Our staff will contact you shortly
		</div>';
           }
       
       }
       


?>
