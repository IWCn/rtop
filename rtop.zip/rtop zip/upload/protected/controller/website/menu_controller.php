<?php
$get_category=$db->get_all('category');
?>