<?php
class links{
	
	public function link($pagename,$panel=NULL,$query=NULL)
	{
		
if($panel==website)
	return SITE_URL."/index.php?".website."=".$pagename.$query;

else 
	return SITE_URL.'/index.php?'.user.'='.$pagename.$query;
		
		
		
	}
	public function hrefquery()
	{
		$request=$_SERVER['REQUEST_URI'];

		$parsed= explode('?', $request);
	
		
       $parsed=explode('=',$parsed['2']);
      
	return $parsed;
	
		
		
	}
	
}
?>