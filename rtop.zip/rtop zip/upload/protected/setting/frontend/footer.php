
  <script src="http://code.jquery.com/jquery-1.10.2.min.js" type="text/javascript">  </script>
  <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js" type="text/javascript"></script>
  
  <script src="<?php echo SITE_URL.'/assets/frontend/js/bootstrap.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/raphael.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/selectivizr-min.js';?>" type="text/javascript"> </script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.mousewheel.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.vmap.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.vmap.sampledata.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.vmap.world.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.bootstrap.wizard.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/fullcalendar.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/gcal.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.dataTables.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/datatable-editable.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.easy-pie-chart.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/excanvas.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.isotope.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/isotope_extras.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/modernizr.custom.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.fancybox.pack.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/select2.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/styleswitcher.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/wysiwyg.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/summernote.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.inputmask.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.validate.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/bootstrap-fileupload.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/bootstrap-datepicker.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/bootstrap-timepicker.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/bootstrap-colorpicker.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/bootstrap-switch.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/typeahead.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/daterange-picker.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/date.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/spin.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/ladda.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/moment.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/morris.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/skycons.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/fitvids.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/jquery.sparkline.min.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/respond.js';?>" type="text/javascript"></script>
  <script src="<?php echo SITE_URL.'/assets/frontend/js/main.js';?>" type="text/javascript"></script>