<?php
define("DB_HOST", "localhost");
define("DB_NAME", "Enter database name here");
define("DB_USER", "Enter dataabse username here");
define("DB_PASSWORD", "Enter database password here");
define("frontend", "user"); // do not edit
define("website", "website"); // do not edit
?>
