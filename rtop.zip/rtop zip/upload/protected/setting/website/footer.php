
<?php $setting=$db->get_row('setting',array('id'=>1)); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/jquery-ui-1.10.4.custom.min.js';?>"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/bootstrap.min.js';?>"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/jquery.flexslider-min.js';?>"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/jquery.bxslider.min.js';?>"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/jquery.fitvids.js';?>"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/lightbox-2.6.min.js';?>"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/simpleCart.min.js';?>"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/skroll.js';?>"></script>
		<script src="<?php echo SITE_URL.'/assets/website/js/restaurante.js';?>"></script>
		
		<script>jQuery(document).ready(function(){
			simpleCart({
			    checkout: { 	
			        type: "PayPal" , 
			        email: "<?php echo  $setting['paypal_email'];?>" ,

			        // use paypal sandbox, default is false
			         sandbox: <?php echo $setting['paypal_live'];?> , 

			        // http method for form, "POST" or "GET", default is "POST"
			        method: "GET" , 

			        // url to return to on successful checkout, default is null
			        success: "<?php echo $link->link('home',website);?>",
			        cancel: "<?php echo SITE_URL;?>" 

			      
			    } 
			});
		});

        </script>
        

		</body>
		</html>