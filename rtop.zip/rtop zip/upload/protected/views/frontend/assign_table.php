 <div class="container-fluid main-content">
<div class="row">
<div class="col-md-12">
<h2>Assign Table </h2></div></div>
 
 

  
 <div class="row">
  <div class="col-md-12">

<div class="widget-container fluid-height clearfix">
<div class="widget-content padded">



 <div class="row">
  <div class="col-md-12">
  
<div class="col-md-7">
 <form method="post" class="form-horizontal" action="" >

     <div class="form-group">
  
  
            <strong>Name : </strong><?php echo $select['name'];?><br></div>
           <div class="form-group"><strong>No. of Persons : </strong> <?php echo $select['person']?><br></div>
            <div class="form-group"><strong>E-Mail : </strong> <?php echo $select['email'];?><br></div>
              <div class="form-group"><strong>Phone No. : </strong> <?php echo $select['phone_no'];?><br></div>
                <div class="form-group"><strong>Date : </strong> <?php echo $select['date'];?>
              <strong> Time : </strong>  <?php echo $select['time']; ?> <br></div>
    
     <div class="form-group">    
 <label class="control-label col-md-1">Assign Table</label>
<div class="col-md-5">
     <select class="form-control" name="table"  >
               <option value="">------------Select--------------------</option>
                <?php 
                if (is_array($get))
                    foreach ($get as $get1){?>
                    <option value="<?php echo $get1['id'];?>" <?php if($_POST['table']==$get1['id']){echo "selected";}?> ><?php echo "( Table No : ".$get1['table_no']. " )  ( Room No :  ".$get1['room']. " )";?></option>
			<?php } ?>
              
            </select> </div></div>
     
       
         
         <div class="form-group">
   <div class="col-md-6">  
    <button class="btn btn-lg btn-block btn-success" type="submit" name="submit"><i class="icon-check"></i>Assign Table</button>
   </div>
    </div></form></div> <div class="col-md-5"></div>
  </div> 
  
  
 </div> </div></div></div>
</div>
 </div>
 

