-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 10, 2015 at 03:53 AM
-- Server version: 5.5.42-cll
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chimpu_restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_heading` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `banner_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `banner` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `banner_heading`, `banner_text`, `banner`, `created_date`, `ip_address`, `timestamp`) VALUES
(1, 'Restaurante', 'Best Restaurante', 'banner.jpg', '15-07-28 09:14:26', '182.69.172.14', '2015-08-06 21:17:41');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE IF NOT EXISTS `booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `person` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `table` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `staff_verified` tinyint(4) NOT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `guests` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `name`, `person`, `date`, `time`, `email`, `phone_no`, `table`, `staff_verified`, `room`, `timestamp`, `created_date`, `ip_address`, `guests`) VALUES
(20, 'Jose', '2', '12-08-2015', '15:15', 'micahel@gmail.com', '555555555', '', 0, '', '2015-08-09 22:21:22', '15-08-09 06:21:22', '122.176.176.45', 0),
(21, 'Daniel', '4', '08-15-2015', '18:15', 'daniel@gmail.com', '6666666666', '2', 1, '2', '2015-08-09 22:22:23', '15-08-09 06:22:14', '122.176.176.45', 0);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`, `created_date`, `ip_address`, `timestamp`) VALUES
(1, 'Welcome Drink', '15-07-30 07:03:25', '127.0.0.1', '2015-07-30 07:03:25'),
(2, 'Soup', '15-07-30 07:12:11', '127.0.0.1', '2015-07-30 07:12:11'),
(6, 'Main Course', '15-07-30 07:18:43', '127.0.0.1', '2015-07-30 07:18:43'),
(9, 'Dessert', '15-07-30 07:23:26', '127.0.0.1', '2015-07-30 07:23:26');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact_msg` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `contact_email`, `contact_msg`, `ip_address`, `created_date`, `timestamp`) VALUES
(1, 'lyn@gmail.com', 'Hey, I want to know more about your site.', '182.64.53.87', '15-08-07 03:45:56', '0000-00-00 00:00:00'),
(2, 'allen_jen@hotmail.com', 'Hey, please tell me more details about your site.', '182.64.53.87', '15-08-07 03:46:58', '0000-00-00 00:00:00'),
(3, 'dsds@sd.jhj', 'defrde', '182.64.53.87', '15-08-07 04:28:59', '0000-00-00 00:00:00'),
(4, 'dfhy@vbn.urtf', 'urtu', '182.64.53.87', '15-08-07 04:40:47', '0000-00-00 00:00:00'),
(5, 'sd@gh.hhf', 'hnfgh', '182.64.53.87', '15-08-07 05:12:31', '0000-00-00 00:00:00'),
(6, 'lyn@gmail.com', 'Hey, I want to know more about your site.', '182.64.53.87', '15-08-07 06:11:52', '0000-00-00 00:00:00'),
(7, 'lyn@gmail.com', 'Hey, I want to know more about your site.', '182.64.53.87', '15-08-07 08:11:35', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `editor`
--

CREATE TABLE IF NOT EXISTS `editor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notes` longtext COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `editor`
--

INSERT INTO `editor` (`id`, `notes`, `timestamp`, `ip_address`, `created_date`) VALUES
(1, 'This is a demo version of&amp;nbsp;Restaurante, responsive website template for all kinds of restaurants, cafes, and bistros. Please make sure to view some&amp;nbsp;more design examples&amp;nbsp;which may be more suitable for your business type. The template comes with complete installation manual, but remember you can always visit our&amp;nbsp;support forums&amp;nbsp;if you have any additional questions.Below you will find a&amp;nbsp;working online ordering example, a module that is&amp;nbsp;only available with purchased copies&amp;nbsp;of this template. All pirated and free, non original verisions will have this functionality disabled, among many other features.', '2015-08-08 23:43:26', '182.69.65.6', '15-07-23 12:07:45');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `event_loc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `event_des` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `event_name`, `post_by`, `event_loc`, `event_des`, `date`, `time`, `image`, `created_date`, `ip_address`, `timestamp`) VALUES
(2, 'Birthday', 'Sofia', 'Chicago', 'Birthday Party...', '17-09-2015', '10:00 PM', '2.jpg', '15-07-29 11:53:40', '182.64.53.87', '2015-08-07 09:37:11'),
(3, 'Meeting', 'Mason', 'Los Angeles', 'Meeting on that day.', '14-08-2015', '06:00 PM', '3.jpg', '15-07-29 11:54:18', '182.64.89.3', '2015-08-06 12:24:04'),
(5, 'Bachelorette Party', 'Abigail', 'Jacksonville', 'Dress Code  - Black & Red', '17-09-2015', '10:00 PM', '5.jpg', '15-08-06 02:54:15', '182.64.53.87', '2015-08-07 06:38:29');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE IF NOT EXISTS `food` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `food_category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `detail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `food_category`, `tags`, `category`, `name`, `detail`, `price`, `image`, `created_date`, `ip_address`, `timestamp`) VALUES
(1, 'Welcome Drink', 'Chocolate', 'Welcome Drink', 'Chocolate Milkshake', 'Special Welcome Drink', '125', '1.jpg', '15-07-30 07:03:25', '182.64.53.87', '2015-08-07 07:10:51'),
(2, 'Welcome Drink', 'Hot Chocolate', 'Welcome Drink', 'Hot Chocolate with Marshmallows', 'Special Welcome Drink', '345', '2.jpg', '15-07-30 07:06:11', '182.64.53.87', '2015-08-07 07:03:09'),
(3, 'Welcome Drink', 'Juice', 'Welcome Drink', 'Orange Juice', 'Juice', '345', '3.jpg', '15-07-30 07:07:39', '182.64.53.87', '2015-08-07 07:15:58'),
(4, 'Welcome Drink', 'Sweet,Salty,spicy', 'Welcome Drink', 'Lemonade', 'Lemonade', '345', '4.jpg', '15-07-30 07:09:42', '182.64.53.87', '2015-08-07 07:17:32'),
(5, 'Soup', 'Spicy,Sweet,Salty', 'Soup', 'Tamato Basil Shorba', 'Monday Special', '345', '5.jpg', '15-07-30 07:12:11', '127.0.0.1', '2015-07-30 07:12:11'),
(6, 'Soup', 'Spicy,Sweet,Salty', 'Soup', 'Hot and Sour Soup', 'Tuesday Special', '345', '6.jpg', '15-07-30 07:13:11', '127.0.0.1', '2015-07-30 07:13:11'),
(12, 'Dessert', 'Sugar ,Sugar free', 'Dessert', 'Brownies', 'Blood Orange Olive Oil Brownies', '100', '12.jpg', '15-07-30 07:23:26', '182.64.53.87', '2015-08-07 07:21:03'),
(13, 'Dessert', 'Sugar, Sugar free', 'Dessert', 'Apple Pie', 'Apple Pie with Ice Cream', '150', '13.jpg', '15-07-30 07:24:47', '182.64.53.87', '2015-08-07 07:22:00'),
(18, 'Main Course', 'Chicken', 'Main Course', 'Braised Chicken Thighs with Savory Marinated Peaches', 'Chicken Thighs in Tomato-Ginger Sauce', '450', '18.jpg', '15-08-07 03:25:15', '182.64.53.87', '2015-08-07 07:25:15'),
(19, 'Main Course', 'Burgers', 'Main Course', 'Garlicky White Bean Burgers', 'Garlicky White Bean Burgers', '400', '19.jpg', '15-08-07 03:26:15', '182.64.53.87', '2015-08-07 07:26:15');

-- --------------------------------------------------------

--
-- Table structure for table `image_category`
--

CREATE TABLE IF NOT EXISTS `image_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `image_category`
--

INSERT INTO `image_category` (`id`, `image_category`, `created_date`, `timestamp`, `ip_address`) VALUES
(1, 'Food', '15-07-30 10:16:28', '2015-07-30 10:16:28', '127.0.0.1'),
(2, 'restaurant', '15-07-30 10:18:27', '2015-07-30 10:18:27', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `image_name`
--

CREATE TABLE IF NOT EXISTS `image_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image_category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `new_category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=46 ;

--
-- Dumping data for table `image_name`
--

INSERT INTO `image_name` (`id`, `image_name`, `image_category`, `new_category`, `image`, `created_date`, `timestamp`, `ip_address`) VALUES
(29, 'food2', 'Food', 'Food', '29.jpg', '15-07-30 01:14:40', '2015-07-30 13:14:40', '127.0.0.1'),
(30, 'food3', 'Food', 'Food', '30.jpg', '15-07-30 01:14:48', '2015-07-30 13:14:48', '127.0.0.1'),
(31, '1', 'restaurant', 'restaurant', '31.jpg', '15-07-30 01:16:36', '2015-07-30 13:16:36', '127.0.0.1'),
(32, '2', 'restaurant', 'restaurant', '32.jpg', '15-07-30 01:16:43', '2015-07-30 13:16:43', '127.0.0.1'),
(33, '3', 'restaurant', 'restaurant', '33.jpg', '15-07-30 01:16:50', '2015-07-30 13:16:50', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `food_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `food_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `food_id`, `food_name`, `price`, `quantity`, `total`, `created_date`, `ip_address`, `timestamp`) VALUES
(1, '1', 'Chocolate Milkshake', 125, 2, 250, '15-08-08 03:05:54', '182.64.164.0', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_final`
--

CREATE TABLE IF NOT EXISTS `order_final` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `client_id` int(11) NOT NULL,
  `products` longtext COLLATE utf8_unicode_ci NOT NULL,
  `payment_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `total_amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `order_final`
--

INSERT INTO `order_final` (`id`, `notes`, `client_id`, `products`, `payment_type`, `total_amount`, `ip_address`, `created_date`, `timestamp`) VALUES
(1, 'Order Fast Please.....................', 24, 'a:2:{i:0;a:9:{s:2:"id";s:1:"1";s:7:"food_id";s:1:"4";s:9:"food_name";s:8:"Lemonade";s:5:"price";s:3:"345";s:8:"quantity";s:1:"2";s:5:"total";s:3:"690";s:12:"created_date";s:17:"15-08-07 05:08:09";s:10:"ip_address";s:12:"182.64.53.87";s:9:"timestamp";s:19:"0000-00-00 00:00:00";}i:1;a:9:{s:2:"id";s:1:"2";s:7:"food_id";s:1:"4";s:9:"food_name";s:8:"Lemonade";s:5:"price";s:3:"345";s:8:"quantity";s:1:"2";s:5:"total";s:3:"690";s:12:"created_date";s:17:"15-08-07 05:08:12";s:10:"ip_address";s:12:"182.64.53.87";s:9:"timestamp";s:19:"0000-00-00 00:00:00";}}', 'credit', '1380', '182.64.53.87', '15-08-07 05:08:37', '0000-00-00 00:00:00'),
(2, 'Order For Birthday..............', 24, 'a:2:{i:0;a:9:{s:2:"id";s:1:"1";s:7:"food_id";s:2:"19";s:9:"food_name";s:27:"Garlicky White Bean Burgers";s:5:"price";s:3:"400";s:8:"quantity";s:1:"2";s:5:"total";s:3:"800";s:12:"created_date";s:17:"15-08-07 05:30:02";s:10:"ip_address";s:12:"182.64.53.87";s:9:"timestamp";s:19:"0000-00-00 00:00:00";}i:1;a:9:{s:2:"id";s:1:"2";s:7:"food_id";s:1:"3";s:9:"food_name";s:12:"Orange Juice";s:5:"price";s:3:"345";s:8:"quantity";s:1:"2";s:5:"total";s:3:"690";s:12:"created_date";s:17:"15-08-07 05:30:05";s:10:"ip_address";s:12:"182.64.53.87";s:9:"timestamp";s:19:"0000-00-00 00:00:00";}}', 'check', '1490', '182.64.53.87', '15-08-07 05:30:57', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `room`, `ip_address`, `created_date`, `timestamp`) VALUES
(1, '1', '127.0.0.1', '15-07-29 11:48:13', '0000-00-00 00:00:00'),
(2, '2', '127.0.0.1', '15-07-29 11:48:32', '0000-00-00 00:00:00'),
(3, '5', '182.64.89.3', '15-08-06 02:44:49', '0000-00-00 00:00:00'),
(4, '6', '182.64.89.3', '15-08-06 05:10:51', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE IF NOT EXISTS `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `paypal_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `paypal_live` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enable` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `currency` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tues` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `wed` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `thurs` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fri` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sun` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `logo`, `name`, `phone_no`, `paypal_email`, `paypal_live`, `enable`, `email`, `currency`, `address`, `title`, `description`, `keywords`, `mon`, `tues`, `wed`, `thurs`, `fri`, `sat`, `sun`, `created_date`, `ip_address`, `timestamp`) VALUES
(1, 'logo.png', 'RESTAURANTE', ' +1 212-947-3838', 'demo@lorem.com', 'true', 'yes', 'restaurante@restaurante.com', '$', '88 W 36th Street, Manhattan, NY 10018 ', 'RESTAURANTE', 'Restaurante - Perfect One Page Website Template For Restaurants.', 'Restaurante, restaurant, template, html5, css3, jquery, responsive, retina', '08:30 - 19:00', '08:30 - 19:00', '08:30 - 19:00', '08:30 - 19:00', '08:30 - 19:00', '08:30 - 19:00', 'Closed', '15-07-23 10:47:12', '122.176.176.45', '2015-08-09 22:17:59');

-- --------------------------------------------------------

--
-- Table structure for table `social`
--

CREATE TABLE IF NOT EXISTS `social` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facebook` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `youtube` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `google` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `twitter` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dribbble` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `stumbleupon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `linkedin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pinterest` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tumblr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `instagram` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vimeo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `flickr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `digg` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `social`
--

INSERT INTO `social` (`id`, `facebook`, `youtube`, `google`, `twitter`, `dribbble`, `stumbleupon`, `linkedin`, `pinterest`, `tumblr`, `instagram`, `vimeo`, `flickr`, `digg`, `ip_address`, `created_date`, `timestamp`) VALUES
(1, 'http://www.facebook.com', 'http://www.youtube.com', 'http://www.google.com', 'http://www.twitter.com', 'http://www.dribbble.com', 'http://www.stumbleupon.com', 'http://www.linkedin.com', 'http://www.pinterest.com', 'http://www.tumblr.com', 'http://www.instagram.com', 'http://www.vimeo.com', 'http://www.flickr.com', 'http://www.digg.com', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `table`
--

CREATE TABLE IF NOT EXISTS `table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `available_place` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `table_pos` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `new_room` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `table`
--

INSERT INTO `table` (`id`, `table_no`, `available_place`, `table_pos`, `room`, `new_room`, `image`, `ip_address`, `created_date`, `timestamp`) VALUES
(1, '1', '2', 'Right', '1', '1', '1.jpg', '182.64.89.3', '15-07-29 11:48:13', '2015-08-06 06:42:45'),
(2, '2', '3', 'corner', '2', '2', '2.jpg', '127.0.0.1', '15-07-29 11:48:32', '2015-07-29 11:48:32'),
(3, '4', '4', 'Center', '1', '1', '', '182.64.89.3', '15-08-05 12:40:21', '2015-08-06 06:43:04'),
(4, '5', '6', 'Corner', '1', '1', '', '182.64.89.3', '15-08-05 01:02:36', '2015-08-06 06:45:16'),
(5, '7', '5', 'At Right Corner in Back', '5', '5', '', '182.64.89.3', '15-08-06 02:44:49', '0000-00-00 00:00:00'),
(6, '8', '3', 'Right in Back', '6', '6', '', '182.64.89.3', '15-08-06 05:10:51', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE IF NOT EXISTS `testimonial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `work_at` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `name`, `job`, `work_at`, `content`, `image`, `created_date`, `ip_address`, `timestamp`) VALUES
(10, 'Elijah', 'Gym Trainer', 'Phoenix', 'This was indeed an unforgettable experience; the beauty of the property, the old trees and the general ambience of the whole place. The art in the main lobby, the placement of other spectacular pieces made this a special experience. Thank you !!', '10.jpg', '15-08-06 09:15:32', '182.64.89.3', '2015-08-06 13:15:46'),
(11, 'Charlotte', 'Designer', 'Las Vegas', 'What a wonderful time we had at the book launch here! Everything was organized to the last perfect detail. And the hospitality, we have been so spoilt that I doubt we can adjust anywhere else, thank you !!', '11.jpg', '15-08-06 09:16:09', '182.64.89.3', '2015-08-06 13:16:15'),
(13, 'Lyn', 'Business', 'San Diego', 'Thank you for taking such excellent care of us. Caring professional staff and great F&B.', '13.jpg', '15-08-06 09:16:58', '182.64.89.3', '2015-08-06 13:16:58'),
(15, 'Riley', 'Doctor', 'New York', 'This is a very special place - wonderful! Thank you for your hospitality and the excellent service!', '15.jpg', '15-08-07 05:41:10', '182.64.53.87', '2015-08-07 09:41:10');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `role`, `name`, `email`, `password`, `phone_no`, `ip_address`, `created_date`, `timestamp`) VALUES
(19, 'Administrator', 'admin', 'admin@gmail.com', '$2y$10$mgzvrkZypedDoSrF.kQhIOx/yN4MdZRHM9qIdditKIT4VZlWB1P1O', '88888', '127.0.0.1', '15-07-29 12:43:19', '0000-00-00 00:00:00'),
(24, 'Client', 'Ruchi', 'ruchi@gmail.com', '$2y$10$r90DaMa9GFCKb2H.KGqlJ.c0VRtZBzdUzf/dUMCzCpRzns0sCV0Dy', '1234567', '182.64.53.87', '15-08-07 05:06:51', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
